import { HeroSection } from "@/components/HeroSection";
import { AnalysisSection } from "@/components/AnalysisSection";
import { TeamFooter } from "@/components/TeamFooter";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <HeroSection />
      <AnalysisSection />
      <TeamFooter />
    </div>
  );
};

export default Index;