import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Bot, User, TrendingUp, AlertTriangle, CheckCircle } from "lucide-react";
import { cn } from "@/lib/utils";

interface AnalysisResult {
  aiPercentage: number;
  humanPercentage: number;
  confidence: number;
  analysis: string;
  type: 'text' | 'image';
}

interface ResultsVisualizationProps {
  result: AnalysisResult | null;
  isAnalyzing: boolean;
}

export const ResultsVisualization = ({ result, isAnalyzing }: ResultsVisualizationProps) => {
  if (isAnalyzing) {
    return (
      <Card className="bg-gradient-card border-border/50 h-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-trust-blue animate-pulse" />
            Analysis in Progress
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-card/50 p-4 rounded-lg border animate-pulse">
              <div className="h-4 bg-muted rounded mb-2"></div>
              <div className="h-8 bg-muted rounded"></div>
            </div>
            <div className="bg-card/50 p-4 rounded-lg border animate-pulse">
              <div className="h-4 bg-muted rounded mb-2"></div>
              <div className="h-8 bg-muted rounded"></div>
            </div>
          </div>
          <div className="space-y-3">
            <div className="h-4 bg-muted rounded animate-pulse"></div>
            <div className="h-4 bg-muted rounded animate-pulse w-3/4"></div>
            <div className="h-4 bg-muted rounded animate-pulse w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!result) {
    return (
      <Card className="bg-gradient-card border-border/50 h-full flex items-center justify-center">
        <CardContent className="text-center py-16">
          <Bot className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
          <h3 className="text-xl font-semibold mb-2">Ready for Analysis</h3>
          <p className="text-muted-foreground">
            Upload content to see detailed AI vs Human detection results
          </p>
        </CardContent>
      </Card>
    );
  }

  const isAIDominant = result.aiPercentage > result.humanPercentage;
  const dominantType = isAIDominant ? 'AI' : 'Human';
  const dominantPercentage = isAIDominant ? result.aiPercentage : result.humanPercentage;

  return (
    <Card className="bg-gradient-card border-border/50">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            {isAIDominant ? (
              <Bot className="w-5 h-5 text-ai-alert" />
            ) : (
              <User className="w-5 h-5 text-human-success" />
            )}
            Detection Results
          </span>
          <Badge 
            variant="outline" 
            className={cn(
              "font-semibold",
              isAIDominant ? "border-ai-alert text-ai-alert" : "border-human-success text-human-success"
            )}
          >
            {dominantType}: {dominantPercentage.toFixed(1)}%
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* AI vs Human Comparison */}
        <div className="grid grid-cols-2 gap-4">
          <div className={cn(
            "p-4 rounded-lg border transition-all",
            isAIDominant ? "bg-gradient-ai/10 border-ai-alert/30 shadow-ai" : "bg-card/50 border-border"
          )}>
            <div className="flex items-center gap-2 mb-2">
              <Bot className="w-4 h-4 text-ai-alert" />
              <span className="text-sm font-medium">AI Generated</span>
            </div>
            <div className="text-2xl font-bold text-ai-alert">
              {result.aiPercentage.toFixed(1)}%
            </div>
            <Progress 
              value={result.aiPercentage} 
              className="mt-2 h-2"
              style={{
                // @ts-ignore
                '--progress-background': 'hsl(var(--ai-alert))'
              }}
            />
          </div>

          <div className={cn(
            "p-4 rounded-lg border transition-all",
            !isAIDominant ? "bg-gradient-human/10 border-human-success/30 shadow-human" : "bg-card/50 border-border"
          )}>
            <div className="flex items-center gap-2 mb-2">
              <User className="w-4 h-4 text-human-success" />
              <span className="text-sm font-medium">Human Created</span>
            </div>
            <div className="text-2xl font-bold text-human-success">
              {result.humanPercentage.toFixed(1)}%
            </div>
            <Progress 
              value={result.humanPercentage} 
              className="mt-2 h-2"
              style={{
                // @ts-ignore
                '--progress-background': 'hsl(var(--human-success))'
              }}
            />
          </div>
        </div>

        {/* Confidence Score */}
        <div className="bg-card/50 p-4 rounded-lg border">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              {result.confidence >= 90 ? (
                <CheckCircle className="w-4 h-4 text-human-success" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-ai-warning" />
              )}
              <span className="text-sm font-medium">Confidence Score</span>
            </div>
            <span className="text-lg font-bold text-trust-blue">
              {result.confidence.toFixed(1)}%
            </span>
          </div>
          <Progress value={result.confidence} className="h-2" />
        </div>

        {/* Analysis Explanation */}
        <div className="bg-card/30 p-4 rounded-lg border border-trust-blue/20">
          <h4 className="font-medium mb-2 text-trust-blue">Analysis Explanation</h4>
          <p className="text-sm text-muted-foreground leading-relaxed">
            {result.analysis}
          </p>
        </div>

        {/* Detection Features */}
        <div className="grid grid-cols-2 gap-3 text-xs">
          <div className="flex items-center gap-2 text-muted-foreground">
            <div className="w-2 h-2 bg-trust-blue rounded-full"></div>
            Multi-model verification
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <div className="w-2 h-2 bg-trust-blue rounded-full"></div>
            Pattern recognition
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <div className="w-2 h-2 bg-trust-blue rounded-full"></div>
            Neural fingerprinting
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <div className="w-2 h-2 bg-trust-blue rounded-full"></div>
            Statistical analysis
          </div>
        </div>
      </CardContent>
    </Card>
  );
};