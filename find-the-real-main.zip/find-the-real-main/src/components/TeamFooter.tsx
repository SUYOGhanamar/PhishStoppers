import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Github, Linkedin, Users, Trophy } from "lucide-react";

export const TeamFooter = () => {
  const teamMembers = [
    {
      name: "Suyog Hanamar",
      linkedin: "https://www.linkedin.com/in/suyog-hanamar-57211b300/",
      github: "https://github.com/SUYOGhanamar",
    },
    {
      name: "Chirag M Kamble", 
      linkedin: "https://www.linkedin.com/in/chirag-kamble-b9aa952bb/",
      github: "https://github.com/chiragmkamble1018",
    }
  ];

  return (
    <footer className="bg-gradient-hero border-t border-border/50 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-card/50 backdrop-blur-sm rounded-full border border-trust-blue/30 mb-6">
            <Trophy className="w-4 h-4 text-ai-warning" />
            <span className="text-sm font-medium text-ai-warning">Hackathon Project</span>
          </div>
          
          <h2 className="text-3xl font-bold mb-4">
            Team <span className="text-trust-blue">Pish Stoppers</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Building the future of AI detection technology with innovative solutions 
            for content authenticity and digital trust.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {teamMembers.map((member, index) => (
            <Card key={index} className="bg-gradient-card border-border/50 hover:shadow-glow transition-all duration-300">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-8 h-8 text-primary-foreground" />
                </div>
                
                <h3 className="text-xl font-semibold mb-4">{member.name}</h3>
                
                <div className="flex justify-center gap-3">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    asChild
                    className="hover:shadow-glow transition-all"
                  >
                    <a 
                      href={member.linkedin} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center gap-2"
                    >
                      <Linkedin className="w-4 h-4" />
                      LinkedIn
                    </a>
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    size="sm" 
                    asChild
                    className="hover:shadow-glow transition-all"
                  >
                    <a 
                      href={member.github} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center gap-2"
                    >
                      <Github className="w-4 h-4" />
                      GitHub
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12 pt-8 border-t border-border/30">
          <p className="text-sm text-muted-foreground">
            © 2024 Find the Fake - AI Detection Platform | Built with ❤️ for Innovation
          </p>
        </div>
      </div>
    </footer>
  );
};