import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { FileText, Image, Upload, Zap } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ResultsVisualization } from "./ResultsVisualization";

interface AnalysisResult {
  aiPercentage: number;
  humanPercentage: number;
  confidence: number;
  analysis: string;
  type: 'text' | 'image';
}

export const AnalysisSection = () => {
  const [activeTab, setActiveTab] = useState<'text' | 'image'>('text');
  const [textInput, setTextInput] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const { toast } = useToast();

  const simulateAnalysis = async (type: 'text' | 'image', content: string) => {
    setIsAnalyzing(true);
    setProgress(0);
    
    // Simulate progressive analysis
    const intervals = [20, 45, 70, 85, 100];
    for (const target of intervals) {
      await new Promise(resolve => setTimeout(resolve, 400));
      setProgress(target);
    }
    
    // Simulate random but realistic results
    const aiPercentage = Math.random() * 100;
    const humanPercentage = 100 - aiPercentage;
    const confidence = 85 + Math.random() * 10; // 85-95% confidence
    
    const analysisTexts = [
      "Advanced pattern recognition detected characteristic AI writing patterns in sentence structure and vocabulary choices.",
      "Neural fingerprint analysis revealed statistical anomalies consistent with large language model generation.",
      "Cross-validation with multiple detection models confirms high probability of AI authorship.",
      "Natural language patterns and stylistic elements strongly suggest human authorship with organic variation.",
      "Deepfake detection algorithms identified subtle pixel-level inconsistencies typical of GAN-generated content."
    ];
    
    const mockResult: AnalysisResult = {
      aiPercentage: parseFloat(aiPercentage.toFixed(1)),
      humanPercentage: parseFloat(humanPercentage.toFixed(1)),
      confidence: parseFloat(confidence.toFixed(1)),
      analysis: analysisTexts[Math.floor(Math.random() * analysisTexts.length)],
      type
    };
    
    setResult(mockResult);
    setIsAnalyzing(false);
    
    toast({
      title: "Analysis Complete",
      description: `${type === 'text' ? 'Text' : 'Image'} analysis finished with ${confidence.toFixed(1)}% confidence.`,
    });
  };

  const handleTextAnalysis = () => {
    if (!textInput.trim()) {
      toast({
        title: "Error",
        description: "Please enter some text to analyze.",
        variant: "destructive",
      });
      return;
    }
    simulateAnalysis('text', textInput);
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      simulateAnalysis('image', file.name);
    }
  };

  return (
    <section className="py-20 bg-background relative">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">
            AI Detection <span className="text-trust-blue">Analysis</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Upload your content and get instant AI vs Human detection results with detailed confidence analysis.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {/* Analysis Input */}
          <div className="space-y-6">
            {/* Tab Selection */}
            <div className="flex bg-card rounded-lg p-1 border">
              <button
                onClick={() => setActiveTab('text')}
                className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-md transition-all ${
                  activeTab === 'text'
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <FileText className="w-4 h-4" />
                Text Analysis
              </button>
              <button
                onClick={() => setActiveTab('image')}
                className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-md transition-all ${
                  activeTab === 'image'
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <Image className="w-4 h-4" />
                Image Analysis
              </button>
            </div>

            {/* Text Analysis */}
            {activeTab === 'text' && (
              <Card className="bg-gradient-card border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="w-5 h-5 text-trust-blue" />
                    Text Content Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Textarea
                    placeholder="Paste your text, article, review, or social media post here..."
                    value={textInput}
                    onChange={(e) => setTextInput(e.target.value)}
                    className="min-h-[200px] resize-none"
                  />
                  <Button 
                    onClick={handleTextAnalysis}
                    disabled={isAnalyzing}
                    className="w-full"
                    variant="hero"
                  >
                    <Zap className="w-4 h-4 mr-2" />
                    {isAnalyzing ? 'Analyzing...' : 'Analyze Text'}
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Image Analysis */}
            {activeTab === 'image' && (
              <Card className="bg-gradient-card border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Image className="w-5 h-5 text-trust-blue" />
                    Image Content Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-2 border-dashed border-border rounded-lg p-8 text-center transition-colors hover:border-trust-blue/50">
                    <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-lg font-medium mb-2">Upload Image for Analysis</p>
                    <p className="text-sm text-muted-foreground mb-4">
                      Support for JPG, PNG, WebP files up to 10MB
                    </p>
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="cursor-pointer"
                      disabled={isAnalyzing}
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Progress Bar */}
            {isAnalyzing && (
              <Card className="bg-card/80 backdrop-blur-sm">
                <CardContent className="pt-6">
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span>Running AI Detection Models...</span>
                      <span>{progress}%</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                    <p className="text-xs text-muted-foreground">
                      Cross-validating with multiple AI detection algorithms
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Results Visualization */}
          <div>
            <ResultsVisualization result={result} isAnalyzing={isAnalyzing} />
          </div>
        </div>
      </div>
    </section>
  );
};