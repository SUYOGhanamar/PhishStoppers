import { Button } from "@/components/ui/button";
import { Shield, Scan, Target } from "lucide-react";
import heroShield from "@/assets/hero-shield.jpg";

export const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center bg-gradient-hero overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-trust-blue rounded-full blur-3xl animate-pulse-glow"></div>
        <div className="absolute bottom-1/4 right-1/4 w-48 h-48 bg-primary rounded-full blur-2xl animate-pulse-glow animation-delay-1000"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left content */}
          <div className="text-center lg:text-left space-y-8">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-card/50 backdrop-blur-sm rounded-full border border-trust-blue/30">
                <Shield className="w-4 h-4 text-trust-blue" />
                <span className="text-sm font-medium text-trust-blue">AI Detection Platform</span>
              </div>
              
              <h1 className="text-5xl lg:text-7xl font-bold leading-tight">
                Find the{" "}
                <span className="bg-gradient-primary bg-clip-text text-transparent">
                  Fake
                </span>
              </h1>
              
              <p className="text-xl text-muted-foreground max-w-lg">
                Detect AI-generated content with state-of-the-art accuracy. 
                Analyze text, reviews, and images to distinguish between 
                human and artificial intelligence creation.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button variant="hero" size="lg" className="group">
                <Scan className="w-5 h-5 mr-2 group-hover:animate-spin transition-transform" />
                Start Analysis
              </Button>
              <Button variant="outline" size="lg">
                <Target className="w-5 h-5 mr-2" />
                View Demo
              </Button>
            </div>
            
            <div className="grid grid-cols-3 gap-8 pt-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-trust-blue">99.2%</div>
                <div className="text-sm text-muted-foreground">Accuracy Rate</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-human-success">10K+</div>
                <div className="text-sm text-muted-foreground">Files Analyzed</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-ai-warning">0.3s</div>
                <div className="text-sm text-muted-foreground">Avg Response</div>
              </div>
            </div>
          </div>
          
          {/* Right content - Hero image */}
          <div className="relative">
            <div className="relative w-full aspect-square max-w-lg mx-auto">
              <img 
                src={heroShield} 
                alt="AI Detection Shield - Cybersecurity visualization" 
                className="w-full h-full object-cover rounded-2xl shadow-glow"
              />
              
              {/* Scanning overlay effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-trust-blue/20 to-transparent animate-scan-line rounded-2xl"></div>
              
              {/* Floating detection badges */}
              <div className="absolute -top-4 -right-4 bg-gradient-ai p-3 rounded-xl shadow-ai">
                <div className="text-center">
                  <div className="text-lg font-bold text-white">AI: 87%</div>
                  <div className="text-xs text-white/80">Detected</div>
                </div>
              </div>
              
              <div className="absolute -bottom-4 -left-4 bg-gradient-human p-3 rounded-xl shadow-human">
                <div className="text-center">
                  <div className="text-lg font-bold text-white">Human: 94%</div>
                  <div className="text-xs text-white/80">Verified</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};